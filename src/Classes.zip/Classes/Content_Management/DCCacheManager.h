//
//  DCCacheManager.h
//  Discord Classic
//
//  Created by Ayeris on 3/20/26.
//  Copyright (c) 2026 Ayeris All rights reserved.
//

#import <UIKit/UIKit.h>

@class DCMessage;
@class DCMessageLayout;
@class DCUser;
@class DCUserInfo;
@class DCEmoji;

@interface DCMessageCacheEntry : NSObject
@property (nonatomic) CGFloat cellHeight;
@property (nonatomic) CGFloat contentHeight;
@property (nonatomic) CGFloat textHeight;
@property (strong, nonatomic) NSAttributedString *attributedContent;
@end

@interface DCCacheManager : NSObject

+ (instancetype)sharedInstance;

// --- Message cache ---
// Store and retrieve full cache entry for a message
- (DCMessageCacheEntry *)cacheEntryForSnowflake:(NSString *)snowflake width:(CGFloat)width;
- (void)setCacheEntry:(DCMessageCacheEntry *)entry forSnowflake:(NSString *)snowflake width:(CGFloat)width;

// Targeted invalidation
- (void)invalidateSnowflake:(NSString *)snowflake;

// --- Layout cache ---
// Composite-key cache for DCMessageLayout, keyed by snowflake, table
// width, immediate neighbor snowflakes, and the message's edited
// timestamp. A change to either neighbor snowflake (insertion or
// eviction at either edge) or to editedTimestamp produces a natural
// cache miss on the next lookup. Other state changes — attachment load
// completing, reference snapshot refresh — don't have version fields in
// the key yet (those land with the DCMessage.h changes in a later
// slice), so callers still need -invalidateSnowflake: for those cases.
- (DCMessageLayout *)layoutForSnowflake:(NSString *)snowflake
                              tableWidth:(CGFloat)tableWidth
                       previousSnowflake:(NSString *)previousSnowflake
                           nextSnowflake:(NSString *)nextSnowflake
                         editedTimestamp:(NSDate *)editedTimestamp;

- (void)setLayout:(DCMessageLayout *)layout
       forSnowflake:(NSString *)snowflake
         tableWidth:(CGFloat)tableWidth
  previousSnowflake:(NSString *)previousSnowflake
      nextSnowflake:(NSString *)nextSnowflake
    editedTimestamp:(NSDate *)editedTimestamp;

// Full flush — use on memory warning or channel change
- (void)invalidateAllMessages;

// --- Avatar cache ---
- (UIImage *)avatarForUserSnowflake:(NSString *)snowflake;
- (void)setAvatar:(UIImage *)image forUserSnowflake:(NSString *)snowflake;

// --- Avatar decoration cache ---
- (UIImage *)decorationForUserSnowflake:(NSString *)snowflake;
- (void)setDecoration:(UIImage *)image forUserSnowflake:(NSString *)snowflake;

// --- Emoji cache ---
- (UIImage *)imageForEmojiSnowflake:(NSString *)snowflake;
- (void)setImage:(UIImage *)image forEmojiSnowflake:(NSString *)snowflake;

// --- Memory management ---
- (void)handleMemoryWarning;

// --- Guild/structure cache (disk-backed) ---
- (void)saveGuilds:(NSArray *)guilds;
- (NSArray *)loadCachedGuilds;
- (void)invalidateGuildCache;

// --- Diaply Layout cache (disk-backed) ---
- (void)saveDisplayLayout:(NSArray *)displayGuilds;
- (NSArray *)loadDisplayLayout;

// --- User Info cache (disk-backed) ---
- (void)saveUserInfo:(DCUserInfo *)userInfo;
- (DCUserInfo *)loadCachedUserInfo;

@end