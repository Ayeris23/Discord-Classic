//
//  DCInfoPageViewController.m
//  Discord Classic
//
//  Created by Trevir on 11/24/18.
//  Copyright (c) 2018 bag.xml. All rights reserved.
//

#import "DCInfoPageViewController.h"

@interface DCInfoPageViewController ()
@property NSArray *creditLinks;
@end

@implementation DCInfoPageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.creditLinks = [NSArray
        arrayWithObjects:@"https://twitter.com/torutheredfox",
                         @"https://bag-xml.com/me/",
                         @"https://twitter.com/trev3d",
                         @"https://github.com/ndcube", @"https://discord.com",
                         @"https://example.com", @"https://example.com", nil];
    
    NSString *version = [[NSUserDefaults standardUserDefaults] stringForKey:@"version"];
    self.versionLabel.text = [NSString stringWithFormat:@"%@", version];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)tableView:(UITableView *)tableView
    didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [UIApplication.sharedApplication
        openURL:[NSURL
                    URLWithString:self.creditLinks
                                      [indexPath.row + indexPath.section * 3]]];
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

@end
