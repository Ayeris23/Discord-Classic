//
//  DCGuild.m
//  Discord Classic
//
//  Created by bag.xml on 3/12/18.
//  Copyright (c) 2018 bag.xml. All rights reserved.
//

#import "DCGuild.h"
#import "DCChannel.h"

@implementation DCGuild

- (NSString*)description {
    return [NSString
        stringWithFormat:
            @"[Guild] Snowflake: %@, Read: %d, Name: %@, Channels: %@",
            self.snowflake, self.unread, self.name, self.channels];
}

- (void)checkIfRead {
    BOOL oldUnread = self.unread;
    if (self.muted && self.mentionCount == 0) {
        // Only suppress unread dot if muted AND no mentions
        self.unread = false;
        goto refreshMarker;
    }
    /*Loop through all child channels
     if any single one is unread, the guild
     as a whole is unread*/
    for (DCChannel *channel in self.channels) {
        if (channel.unread) {
            self.unread = true;
            goto refreshMarker;
        }
    }
    self.unread = false;
refreshMarker:
    if (self.unread != oldUnread) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [NSNotificationCenter.defaultCenter
                postNotificationName:@"RELOAD GUILD"
                              object:self];
        });
    }
}

- (NSInteger)mentionCount {
    NSInteger total = 0;
    for (DCChannel *channel in self.channels) {
        total += channel.mentionCount;
    }
    return total;
}

#pragma mark - NSCoding

- (void)encodeWithCoder:(NSCoder *)aCoder {
    [aCoder encodeObject:self.snowflake   forKey:@"snowflake"];
    [aCoder encodeObject:self.name        forKey:@"name"];
    [aCoder encodeObject:self.ownerID     forKey:@"ownerID"];
    [aCoder encodeInteger:self.memberCount forKey:@"memberCount"];
    [aCoder encodeBool:self.muted         forKey:@"muted"];
    [aCoder encodeObject:self.channels    forKey:@"channels"];
    [aCoder encodeObject:self.iconURL forKey:@"iconURL"];
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];
    if (self) {
        self.snowflake   = [aDecoder decodeObjectForKey:@"snowflake"];
        self.name        = [aDecoder decodeObjectForKey:@"name"];
        self.ownerID     = [aDecoder decodeObjectForKey:@"ownerID"];
        self.memberCount = [aDecoder decodeIntegerForKey:@"memberCount"];
        self.muted       = [aDecoder decodeBoolForKey:@"muted"];
        self.channels    = [aDecoder decodeObjectForKey:@"channels"];
        self.iconURL = [aDecoder decodeObjectForKey:@"iconURL"];

        // These get populated by the live READY — initialize empty so nothing crashes
        self.members   = [NSMutableArray array];
        self.roles     = [NSMutableDictionary dictionary];
        self.userRoles = [NSMutableArray array];
        self.emojis    = [NSMutableDictionary dictionary];
    }
    return self;
}

@end
